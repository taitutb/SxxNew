
(function () {
    if (typeof window.jsb === 'object') {
        var hotUpdateSearchPaths = localStorage.getItem('HotUpdateSearchPaths-game');
        if (hotUpdateSearchPaths) {
            var paths = JSON.parse(hotUpdateSearchPaths);
            jsb.fileUtils.setSearchPaths(paths);

            var fileList = [];
            var storagePath = paths[0] || '';
            var tempPath = storagePath + '_temp/';
            var baseOffset = tempPath.length;

            if (jsb.fileUtils.isDirectoryExist(tempPath) && !jsb.fileUtils.isFileExist(tempPath + 'project.manifest.temp')) {
                jsb.fileUtils.listFilesRecursively(tempPath, fileList);
                fileList.forEach(srcPath => {
                    var relativePath = srcPath.substr(baseOffset);
                    var dstPath = storagePath + relativePath;

                    if (srcPath[srcPath.length] == '/') {
                        cc.fileUtils.createDirectory(dstPath)
                    }
                    else {
                        if (cc.fileUtils.isFileExist(dstPath)) {
                            cc.fileUtils.removeFile(dstPath)
                        }
                        cc.fileUtils.renameFile(srcPath, dstPath);
                    }
                })
                cc.fileUtils.removeDirectory(tempPath);
            }
        }
    }
})();
window.boot = function () {
  var settings = window._CCSettings;
  window._CCSettings = undefined;
  var onProgress = null;

  let { RESOURCES, INTERNAL, MAIN, START_SCENE } = cc.AssetManager.BuiltinBundleName;
  function setLoadingDisplay() {
    // Loading splash scene
    var splash = document.getElementById('splash');
    var progressBar = splash.querySelector('.progress-bar span');
    onProgress = function (finish, total) {
      var percent = (100 * finish) / total;
      if (progressBar) {
        progressBar.style.width = percent.toFixed(2) + '%';
      }
    };
    splash.style.display = 'block';
    progressBar.style.width = '0%';

    cc.director.once(cc.Director.EVENT_AFTER_SCENE_LAUNCH, function () {
      splash.style.display = 'none';
    });
  }

  var onStart = function () {
    cc.view.enableRetina(true);
    cc.view.resizeWithBrowserSize(true);

    if (cc.sys.isBrowser) {
      setLoadingDisplay();
    }

    if (cc.sys.isMobile) {
      if (settings.orientation === 'landscape') {
        cc.view.setOrientation(cc.macro.ORIENTATION_LANDSCAPE);
      } else if (settings.orientation === 'portrait') {
        cc.view.setOrientation(cc.macro.ORIENTATION_PORTRAIT);
      }
      cc.view.enableAutoFullScreen(
        [cc.sys.BROWSER_TYPE_BAIDU, cc.sys.BROWSER_TYPE_BAIDU_APP, cc.sys.BROWSER_TYPE_WECHAT, cc.sys.BROWSER_TYPE_MOBILE_QQ, cc.sys.BROWSER_TYPE_MIUI].indexOf(
          cc.sys.browserType,
        ) < 0,
      );
    }

    // Limit downloading max concurrent task to 2,
    // more tasks simultaneously may cause performance draw back on some android system / browsers.
    // You can adjust the number based on your own test result, you have to set it before any loading process to take effect.
    if (cc.sys.isBrowser && cc.sys.os === cc.sys.OS_ANDROID) {
      cc.assetManager.downloader.maxConcurrency = 2;
      cc.assetManager.downloader.maxRequestsPerFrame = 2;
    }

    var launchScene = settings.launchScene;
    var bundle = cc.assetManager.bundles.find(function (b) {
      return b.getSceneInfo(launchScene);
    });

    bundle.loadScene(launchScene, null, onProgress, function (err, scene) {
      if (!err) {
        cc.director.runSceneImmediate(scene);
        if (cc.sys.isBrowser) {
          // show canvas
          var canvas = document.getElementById('GameCanvas');
          canvas.style.visibility = '';
          var div = document.getElementById('GameDiv');
          if (div) {
            div.style.backgroundImage = '';
          }
          //console.log('Success to load scene: ' + launchScene);
        }
      }
    });
  };

  var option = {
    id: 'GameCanvas',
    debugMode: settings.debug ? cc.debug.DebugMode.INFO : cc.debug.DebugMode.ERROR,
    showFPS: settings.debug,
    frameRate: 60,
    groupList: settings.groupList,
    collisionMatrix: settings.collisionMatrix,
  };

  cc.assetManager.init({
    bundleVers: settings.bundleVers,
    remoteBundles: settings.remoteBundles,
    server: settings.server,
  });

  let bundleRoot = [INTERNAL];
  settings.hasResourcesBundle && bundleRoot.push(RESOURCES);

  var count = 0;
  function cb(err) {
    if (err) return console.error(err.message, err.stack);
    count++;
    if (count === bundleRoot.length + 1) {
      cc.assetManager.loadBundle(MAIN, function (err) {
        if (!err) cc.game.run(option, onStart);
      });
    }
  }

  cc.assetManager.loadScript(
    settings.jsList.map(function (x) {
      return 'src/' + x;
    }),
    cb,
  );

  for (let i = 0; i < bundleRoot.length; i++) {
    cc.assetManager.loadBundle(bundleRoot[i], cb);
  }
};

if (window.jsb) {
  var isRuntime = typeof loadRuntime === 'function';
  if (isRuntime) {
    require('src/cocos2d-runtime.js');
    if (CC_PHYSICS_BUILTIN || CC_PHYSICS_CANNON) {
      require('src/physics.js');
    }
    require('jsb-adapter/engine/index.js');
  } else {
    require('src/cocos2d-jsb.js');
    if (CC_PHYSICS_BUILTIN || CC_PHYSICS_CANNON) {
      require('src/physics.js');
    }
    require('jsb-adapter/jsb-engine.js');
  }
  var ver = 1;
  var verOld = cc.sys.localStorage.getItem('Ver');
  if (verOld) {
    if (verOld < ver) {
      cc.sys.localStorage.setItem('Ver', ver);
      let _storagePath = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : '/') + 'remote-asset';
      jsb.fileUtils.removeDirectory(_storagePath);
    } else {
      //	cc.NGWlog("===================== 1");
      var hotUpdateSearchPaths = cc.sys.localStorage.getItem('HotUpdateSearchPaths');
      if (hotUpdateSearchPaths) {
        jsb.fileUtils.setSearchPaths(JSON.parse(hotUpdateSearchPaths));
      }
    }
  } else {
    cc.sys.localStorage.setItem('Ver', ver);
    let _storagePath = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : '/') + 'remote-asset';
    jsb.fileUtils.removeDirectory(_storagePath);
  }
  // Tự lành search path: localStorage của Cocos chỉ xả xuống đĩa khi app vào nền/thoát sạch. App bị kill cứng
  // thì 'HotUpdateSearchPaths-game' mất trong khi file đã tải vẫn còn trong remote-assets -> lần mở sau chạy bản
  // cũ trong app (hoặc đen màn hình). Suy đường dẫn từ THỨ ĐANG CÓ TRÊN ĐĨA (giống SBDoc UpdateManager._ensureSearchPath).
  try {
    var _hotRoot = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : '/') + 'remote-assets/';
    if (jsb.fileUtils.isFileExist(_hotRoot + 'project.manifest')) {
      var _cur = jsb.fileUtils.getSearchPaths();
      var _has = _cur.some(function (p) {
        return p === _hotRoot || p + '/' === _hotRoot || p === _hotRoot.slice(0, -1);
      });
      if (!_has) {
        _cur.unshift(_hotRoot);
        jsb.fileUtils.setSearchPaths(_cur);
      }
    }
  } catch (e) {}
  require('src/settings.js');
  cc.macro.CLEANUP_IMAGE_CACHE = true;
  window.boot();
}
